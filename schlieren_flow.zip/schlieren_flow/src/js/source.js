// schlieren_flow — source.js
// Handles u_source input: image upload, webcam, or upstream FBO.

export class Source {
  constructor(gl) { this.gl = gl; }
  fromImage(file) { /* TODO */ }
  fromWebcam() { /* TODO */ }
  fromFBO(fbo) { /* TODO */ }
}
