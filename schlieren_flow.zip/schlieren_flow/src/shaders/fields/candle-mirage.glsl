// TODO: fields/candle-mirage.glsl
