// TODO: fields/gas-jet.glsl
