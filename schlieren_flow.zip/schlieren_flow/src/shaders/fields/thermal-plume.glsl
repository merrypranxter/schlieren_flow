// TODO: fields/thermal-plume.glsl
