# schlieren_flow

A creative coding project exploring **schlieren and shadowgraph optics** — visualizing refractive-index gradients that bend light, revealing heat haze, gas plumes, shock waves, and mixing fluids. Ghostly density fields and rainbow schlieren. Lab-photo weird.

## What Is This?

A **generator** that simulates a schlieren optical system: light passes through a region with varying refractive index (density), bends toward higher density, and the deflection is visualized by a knife edge or color filter. The result is a high-pass image of invisible flow structures made visible.

**Bonus:** Can read `u_source` luminance as a density field to schlieren any image through the simulated medium.

## Project Structure

```
src/
  js/
    main.js           — WebGL setup, render loop, parameter UI
    fbo-pingpong.js   — evolving density/temperature field
    color-maps.js     — spectral ramps
  shaders/
    fields/           — swappable density sources
      thermal-plume.glsl   — buoyant heat plume
      gas-jet.glsl         — turbulent injection, curl noise
      shock-wave.glsl      — expanding radial discontinuity
      candle-mirage.glsl   — small wobbling hot source
    evolve.frag       — advect + diffuse + buoyancy (light fluid)
    schlieren.frag    — gradient · knife-edge → brightness; or angle→hue
    post-process.frag — subtle grain, lab-photo grade
```

## Running

Open `index.html` in any modern browser. WebGL2 required.

## Current Field Engines

- [ ] _thermal_plume — buoyant heat rising, classic plume shape
- [ ] _gas_jet — turbulent injection from a nozzle, curl noise
- [ ] _shock_wave — expanding radial discontinuity, sharp ring
- [ ] _candle_mirage — small wobbling hot source, delicate plume

## Aesthetic Regimes

- [ ] wind_tunnel_mono — horizontal knife, grayscale, gas jet, classic aero-lab
- [ ] rainbow_schlieren — color-filter mode, density gradient → spectrum
- [ ] candle_shadowgraph — Laplacian, soft, wobbling plume on white
- [ ] shockwave_bang — expanding radial shock, high contrast

## Parameters

- `field_source` — thermal_plume | gas_jet | shock_wave | candle_mirage
- `knife_mode` — horizontal | vertical | rainbow | shadowgraph
- `sensitivity` — 0.5–5.0 (gradient multiplier)
- `diffusion` — 0.001–0.1 (density field smoothing)
- `buoyancy` — 0.0–2.0 (thermal plume strength)

## Ecosystem Hooks

Shares the light fluid engine with `fluid_dynamics`, `liquid_light_show`, `ferrofluid_dance`. Pairs with `caustic_networks`, `holography`. Sciencey-weird.

---

*The air is invisible until the light bends through it.*
